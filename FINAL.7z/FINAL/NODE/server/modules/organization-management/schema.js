DefalutObj = 
    {
        isVerified: false,
        isDeleted: false,
        profile: {
            followers: [],
            post: [ ],
            jobs: [ ]
        }

    }

module.exports = DefalutObj;